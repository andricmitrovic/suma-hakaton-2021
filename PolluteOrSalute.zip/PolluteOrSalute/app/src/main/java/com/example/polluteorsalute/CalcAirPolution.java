package com.example.polluteorsalute;
/*
* O3_bounds = np.array([ 54, 125, 165, 205, 405, 504, 604], dtype=np.float64) * 2.00
PM25_bounds = np.array([12, 35.4, 55.4, 150.4, 250.4, 350.4, 500.4], dtype=np.float64)
P10_bounds = np.array([54, 154, 254, 354, 424, 504, 604], dtype=np.float64)
CO_bounds = np.array([4.4, 9.4, 12.4, 15.4, 30.4, 40.4, 50.4], dtype=np.float64) * 1.145
SO2_bounds = np.array([35, 75, 185, 304, 604, 804, 1004], dtype=np.float64) * 2.62
NO2_bounds = np.array([53, 100, 360, 649, 1249, 1649, 2049], dtype=np.float64) * 1.88

I_bounds = np.array([50, 100, 150, 200, 300, 400, 500], dtype=np.float64)
* */


import java.util.Arrays;
import java.util.logging.Level;

import static java.lang.Math.abs;
import static java.lang.Math.max;
import static java.lang.Math.min;

public class CalcAirPolution {

    private static float[] o3_bounds = {108, 250, 330, 410, 810, 1008, 1208};
    private static float[] pm25_bounds = {12, 35.4f, 55.4f, 150.4f, 250.4f, 350.4f, 500.4f};
    private static float[] pm10_bounds = {54, 154, 254, 354, 424, 504, 604};
    private static float[] co_bounds = {5.038f, 10.763f, 14.198f, 17.633f, 34.808f, 46.258f, 51.708f};
    private static float[] so2_bounds = {91.7f, 196.5f, 484.7f, 796.48f, 1582.48f, 2106.48f, 2630.48f};
    private static float[] no2_bounds = {99.64f, 188f, 678.8f, 1220.12f, 2348.12f, 3100.12f, 3852.12f};

    private static float[] i_bounds = {50, 100, 150, 200, 300, 400, 500};

    public static float calci(float Clow, float Chigh, float Ilow, float Ihigh, float C) {
        float val = ((Ihigh - Ilow) / (Chigh - Clow)) * (C - Clow) + Ilow;
        System.out.println("------------------------>" + Chigh + " " + Clow + " " + val);
        return val;
    }

    private static int searchsorted(float[] arr, float value) {

        for (int i = 0; i < arr.length; i++) {
            if(value < arr[i])
                return i;
        }

        return arr.length- 1;
    }

    public static float[] calcLowHigh(String dataName, float c) {
        if (dataName.equals("O3")) {

            int index = searchsorted(o3_bounds, c);
            float cHigh = o3_bounds[min(index+1, o3_bounds.length - 1)];
            float cLow = o3_bounds[index];
            float iHigh = i_bounds[min(index+1, o3_bounds.length - 1)];
            float iLow = i_bounds[index];

            return new float[]{cLow, cHigh, iLow, iHigh};
        }

        if (dataName.equals("PM25")) {
            int index = searchsorted(pm25_bounds, c);
            float cHigh = pm25_bounds[min(index+1, pm25_bounds.length - 1)];
            float cLow = pm25_bounds[index];
            float iHigh = i_bounds[min(index+1, pm25_bounds.length - 1)];
            float iLow = i_bounds[index];

            return new float[]{cLow, cHigh, iLow, iHigh};
        }

        if (dataName.equals("PM10")) {
            int index = searchsorted(pm10_bounds, c);
            float cHigh = pm10_bounds[min(index+1, pm10_bounds.length - 1)];
            float cLow = pm10_bounds[index];
            float iHigh = i_bounds[min(index+1, pm10_bounds.length - 1)];
            float iLow = i_bounds[index];

            return new float[]{cLow, cHigh, iLow, iHigh};
        }

        if (dataName.equals("CO")) {
            int index = searchsorted(co_bounds, c);
            float cHigh = co_bounds[min(index+1, co_bounds.length - 1)];
            float cLow = co_bounds[index];
            float iHigh = i_bounds[min(index+1, co_bounds.length - 1)];
            float iLow = i_bounds[index];

            return new float[]{cLow, cHigh, iLow, iHigh};
        }


        if (dataName.equals("SO2")) {
            int index = searchsorted(so2_bounds, c);
            float cHigh = so2_bounds[min(index+1, so2_bounds.length - 1)];
            float cLow = so2_bounds[index];
            float iHigh = i_bounds[min(index+1, so2_bounds.length - 1)];
            float iLow = i_bounds[index];

            return new float[]{cLow, cHigh, iLow, iHigh};
        }
        if (dataName.equals("NO2")) {
            int index = searchsorted(no2_bounds, c);
            float cHigh = no2_bounds[min(index+1, no2_bounds.length - 1)];
            float cLow = no2_bounds[index];
            float iHigh = i_bounds[min(index+1, no2_bounds.length - 1)];
            float iLow = i_bounds[index];

            return new float[]{cLow, cHigh, iLow, iHigh};
        }
        return null;
    }

    private static String get_category(float api) {
        String[] arr = {"good", "moderate", "unhealthy for some", "unhealthy", "very unhealthy", "hazardous"};
        int index = searchsorted(i_bounds, api);
        return arr[min(index, arr.length - 1)];
    }

    public static String calc(float[] arr){
        float max_api = -1f;

        float test = arr[0];
        float[] vals_co = calcLowHigh("CO", test);
        float i_co = calci(vals_co[0], vals_co[1], vals_co[2], vals_co[3], test);

        max_api = max(max_api, i_co);

        float[] vals_no2 = calcLowHigh("NO2", arr[1]);
        float i_no2 = calci(vals_no2[0], vals_no2[1], vals_no2[2], vals_no2[3], arr[1]);
        max_api = max(max_api, i_no2);


        float[] vals_03 = calcLowHigh("O3", arr[2]);
        float i_o3 = calci(vals_03[0],vals_03[1],vals_03[2],vals_03[3], arr[2]);
        max_api = max(max_api, i_o3);

        float[] vals_pm10 = calcLowHigh("PM10", arr[3]);
        float i_pm10 = calci(vals_pm10[0], vals_pm10[1], vals_pm10[2],vals_pm10[3], arr[3]);
        max_api = max(max_api, i_pm10);

        float[] vals_pm25 = calcLowHigh("PM25", arr[4]);
        float i_pm25 = calci(vals_pm25[0], vals_pm25[1], vals_pm25[2], vals_pm25[3], arr[4]);
        max_api = max(max_api, i_pm25);

        float[] vals_so2 = calcLowHigh("SO2", arr[5]);
        float i_so2 = calci(vals_so2[0], vals_so2[1], vals_so2[2], vals_so2[3], arr[5]);
        max_api = max(max_api, i_so2);

        return get_category(max_api) + " " + String.valueOf(max_api);
    }
}