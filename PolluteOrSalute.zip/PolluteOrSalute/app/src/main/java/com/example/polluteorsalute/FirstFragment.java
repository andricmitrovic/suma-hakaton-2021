package com.example.polluteorsalute;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.Arrays;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


public class FirstFragment extends Fragment {


    private EditText etTemperature;
    private EditText etHumidity;
    private EditText etWindSpeed;
    private EditText etWindDirection;
    private EditText etAtmosphericPressure;
    private EditText etVisibility;

    private int resInt;

    private float gTemp;
    private float gHumidity;
    private float gWindSpeed;
    private float gWindDirection;
    private float gAtmosphericPressure;
    private float gVisibility;

    private String filePath;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_first, container, false);
    }

    Call post(Callback callback) {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url("https://community-open-weather-map.p.rapidapi.com/weather?q=Belgrade%2Crs&lat=0&lon=0&callback=test&id=2172797&lang=null&units=%22metric%22%20or%20%22imperial%22&mode=xml%2C%20html")
                .get()
                .addHeader("x-rapidapi-key", "ca05f487d1msh615c238d77c30c8p1ba5c0jsn1a60f87baa5f")
                .addHeader("x-rapidapi-host", "community-open-weather-map.p.rapidapi.com")
                .build();
        Call call = client.newCall(request);
        call.enqueue(callback);
        return call;
    }


    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        etTemperature = view.findViewById(R.id.etTemperature);
        etHumidity = view.findViewById(R.id.etHumidity);
        etWindSpeed = view.findViewById(R.id.etWindSpeed);
        etWindDirection = view.findViewById(R.id.etWindDirection);
        etAtmosphericPressure = view.findViewById(R.id.etAtmosphericPressure);
        etVisibility = view.findViewById(R.id.etVisibility);


        Call response = post(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                // Something went wrong
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                   String responseStr = response.body().string();
                    try {
                        JSONObject obj = new JSONObject(responseStr.substring(5));
                        JSONObject main = (JSONObject) obj.get("main");
                        System.out.println(main.get("temp"));

                        gTemp = Float.parseFloat(main.get("temp").toString()) - 273.15f;
                        gAtmosphericPressure = Float.parseFloat(main.get("pressure").toString());

                        gHumidity = Float.parseFloat(main.get("humidity").toString());

                        JSONObject wind = (JSONObject) obj.get("wind");

                        gWindSpeed = Float.parseFloat(wind.get("speed").toString());
                        gWindDirection = Float.parseFloat(wind.get("deg").toString());

                        gVisibility = Float.parseFloat(obj.get("visibility").toString());

                        System.out.println(obj.toString());
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                } else {
                    Log.e("ERRORCINA", "EPIC FAILO DESU");
                }
            }
        });

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        etTemperature.setText(String.valueOf(gTemp));
        etHumidity.setText(String.valueOf(gHumidity));
        etWindSpeed.setText(String.valueOf(gWindSpeed));
        etWindDirection.setText(String.valueOf(gWindDirection));
        etAtmosphericPressure.setText(String.valueOf(gAtmosphericPressure));
        etVisibility.setText(String.valueOf(gVisibility));

        filePath = Utils.assetFilePath(getActivity(),"modelPT.pt");

        view.findViewById(R.id.button_first).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float temperature = Float.valueOf(etTemperature.getText().toString());
                float humidity = Float.valueOf(etHumidity.getText().toString());
                float windSpeed = Float.valueOf(etWindSpeed.getText().toString());
                float windDirection = Float.valueOf(etWindDirection.getText().toString());
                float atmosphericPressure = Float.valueOf(etAtmosphericPressure.getText().toString());
                float visibility = Float.valueOf(etVisibility.getText().toString());

                Classifier classifier = new Classifier(filePath);

                float[] output = classifier.predict(temperature, atmosphericPressure, humidity, windSpeed, 0, visibility, windDirection);

                String pollution_str = CalcAirPolution.calc(output);


                Bundle bundle = new Bundle();
                bundle.putString("inputData", pollution_str);
                NavHostFragment.findNavController(FirstFragment.this)
                        .navigate(R.id.action_FirstFragment_to_SecondFragment, bundle);
            }
        });
    }
}