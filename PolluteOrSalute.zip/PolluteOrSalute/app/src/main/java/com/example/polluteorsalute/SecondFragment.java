package com.example.polluteorsalute;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

public class SecondFragment extends Fragment {

    private TextView tvScore;
    private ImageView ivEmoji;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_second, container, false);
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        String data = getArguments().getString("inputData");
        tvScore = view.findViewById(R.id.tvScore);
        tvScore.setText(data);

        ivEmoji = view.findViewById(R.id.ivEmoji);
        if(data.startsWith("good")){
            ivEmoji.setImageResource(R.mipmap.s1_round);
        }
        if(data.startsWith("moderate")){
            ivEmoji.setImageResource(R.mipmap.s2_round);
        }
        if(data.startsWith("unhealthy for some")){
            ivEmoji.setImageResource(R.mipmap.s3_round);
        }
        if(data.startsWith("unhealthy")){
            ivEmoji.setImageResource(R.mipmap.s4_round);
        }
        if(data.startsWith("very unhealthy")){
            ivEmoji.setImageResource(R.mipmap.s5_round);
        }
        if(data.startsWith("hazardous")){
            ivEmoji.setImageResource(R.mipmap.s6_round);
        }

        view.findViewById(R.id.button_second).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(SecondFragment.this)
                        .navigate(R.id.action_SecondFragment_to_FirstFragment);
            }
        });
    }
}