package com.example.polluteorsalute;

import android.graphics.Bitmap;
import org.pytorch.Tensor;
import org.pytorch.Module;
import org.pytorch.IValue;
import org.pytorch.torchvision.TensorImageUtils;

import static java.lang.Math.abs;

public class Classifier {

    Module model;

    public Classifier(String modelPath){

        model = Module.load(modelPath);

    }

    public Tensor preProcess(float temperature, float atmosphericPressure, float humidity, float windSpeed, float clouds, float visibility, float windDirection) {
        if(visibility > 10000)
            visibility = 10000;

        visibility /= 100;


        float[] angles = {90, 67.5f, 112.5f, 0, 45, 22.5f, 337.5f, 315, 180, 135, 157.5f, 202.5f, 225, 270, 292.5f, 247.5f};

        int index = 0;

        if(windDirection > 347.5){
            index = 3;
        }else {
            for (int i = 1; i < angles.length; i++) {
                if (abs(angles[i] - windDirection) < 11.25) {
                    index = i;
                }
            }
        }

        float[] tempArr = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
        tempArr[index] = 1f;

        float[] data = {temperature,atmosphericPressure, humidity, windSpeed, clouds, visibility,0, 0,
                tempArr[0],tempArr[1],tempArr[2],tempArr[3],
                tempArr[4],tempArr[5],tempArr[6],tempArr[7],
                tempArr[8],tempArr[9],tempArr[10],tempArr[11],
                tempArr[12],tempArr[13],tempArr[14],tempArr[15], 0};
        long[] shape = {1,25};
        return Tensor.fromBlob(data, shape);
    }


    public float[] predict(float temperature, float atmosphericPressure, float humidity, float windSpeed, float clouds, float visibility, float windDirection){

        Tensor tensor = preProcess(temperature, atmosphericPressure, humidity, windSpeed, clouds, visibility,  windDirection);

        IValue inputs = IValue.from(tensor);
        Tensor outputs = model.forward(inputs).toTensor();

        float[] output = outputs.getDataAsFloatArray();

        return output;
    }

}

/*
DateTime,
T,
P,
U,
Ff,
Nh,
VV,
sss,
"DD_Calm, no wind",
DD_Wind blowing from the east,
DD_Wind blowing from the east-northeast,
DD_Wind blowing from the east-southeast,DD_Wind blowing from the north,DD_Wind blowing from the north-east,DD_Wind blowing from the north-northeast,DD_Wind blowing from the north-northwest,DD_Wind blowing from the north-west,DD_Wind blowing from the south,DD_Wind blowing from the south-east,DD_Wind blowing from the south-southeast,DD_Wind blowing from the south-southwest,DD_Wind blowing from the south-west,DD_Wind blowing from the west,DD_Wind blowing from the west-northwest,DD_Wind blowing from the west-southwest,DD_variable wind direction
 */